---
name: ⛔ Documentation Issue
about: See https://github.com/PX4/px4_user_guide for documentation issues

---

## Attention! Please read the note below

**Please submit the documentation issue to the [User Guide](https://github.com/PX4/px4_user_guide) repository.**

Thanks!
