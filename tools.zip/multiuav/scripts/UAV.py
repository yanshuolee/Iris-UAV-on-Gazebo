import rospy
import tf
from geometry_msgs.msg import PoseStamped, Pose, Point
from mavros_msgs.msg import State
from std_msgs.msg import String
from mavros_msgs.srv import CommandBool, CommandBoolRequest, SetMode, SetModeRequest, CommandTOL
from nav_msgs.msg import Path
from nav_msgs.msg import Odometry
from visualization_msgs.msg import MarkerArray, Marker
import cv2
from std_msgs.msg import String
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import imutils
import time
from datetime import datetime
import pickle
import os
from math import atan2

class image_converter:
  def __init__(self, artag_topic, cam_topic):
    self.tag_pub = rospy.Publisher(artag_topic, String, queue_size=10)

    self.bridge = CvBridge()
    self.image_sub = rospy.Subscriber(cam_topic,Image,self.callback)

    self.arucoDict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_APRILTAG_36h11)
    self.arucoParams = cv2.aruco.DetectorParameters_create()

  def callback(self,data):
    try:
      cv_image = self.bridge.imgmsg_to_cv2(data, "bgr8")
    except CvBridgeError as e:
      print(e)

    image = imutils.resize(cv_image, width=600)
    (corners, ids, rejected) = cv2.aruco.detectMarkers(image, self.arucoDict, parameters=self.arucoParams)
    # print(ids)
    try:
      if ids is None:
        _id = ""
      else:
        _id = str(ids[0][0])
      self.tag_pub.publish(_id)
    except CvBridgeError as e:
      print(e)

class UAV():
    def __init__(self, configs):
        if not os.path.exists(configs["save_path"]):
            os.makedirs(configs["save_path"])
        os.environ["ROS_LOG_DIR"] = configs["save_path"]
        self.save_path = configs["save_path"]
        self.uav_id = configs["uav_id"]

        rospy.init_node(configs["ros_node"])
        self.current_state = State()
        self.R_pose = Pose()
        self.tag_id = ""

        rospy.Subscriber(configs["state_sb"], State, callback = self.state_cb)
        rospy.Subscriber(configs["pose_sb"], PoseStamped, self.pose_callback)
        self.local_pos_pub = rospy.Publisher(configs["local_pb"], PoseStamped, queue_size=10)
        rospy.wait_for_service(configs["arm_srv"])
        self.arming_client = rospy.ServiceProxy(configs["arm_srv"], CommandBool)    

        rospy.wait_for_service(configs["set_mode_srv"])
        self.set_mode_client = rospy.ServiceProxy(configs["set_mode_srv"], SetMode)
        rospy.Subscriber(configs["artag_sb"], String, callback = self.get_id)

        self.traj = Path()
        rospy.Subscriber(configs["pose_sb"], PoseStamped, self.odom_cb)
        self.path_pub = rospy.Publisher(configs["traj"], Path, queue_size=10)

        # marker
        # rospy.Subscriber(configs["pose_sb"], PoseStamped, self.marker_cb)
        # self.marker_array_pub = rospy.Publisher(configs["marker"], Marker,queue_size=10)

        image_converter(configs["artag"], configs["camera"])

        self.rate = rospy.Rate(10)

        # Wait for Flight Controller connection
        while(not rospy.is_shutdown() and not self.current_state.connected):
            rospy.loginfo("Wait for Flight Controller connection")
            self.rate.sleep()

        self.offb_set_mode = SetModeRequest()
        self.offb_set_mode.custom_mode = 'OFFBOARD'

        self.arm_cmd = CommandBoolRequest()
        self.arm_cmd.value = True

        self.results = {
            "ts":[],
            "log":[],
            "id_found":[],
            "id_found_ts":[]
        }

        self.start_t = None
        self.last_req = None
        self.time_constraint = 600

    def state_cb(self, msg):
        self.current_state = msg

    def pose_callback(self, msg):
        self.R_pose = msg.pose

    def get_id(self, msg):
        self.tag_id = msg.data
    
    def odom_cb(self, data):
        self.traj.header = data.header
        pose = PoseStamped()
        pose.header = data.header
        pose.pose = data.pose
        self.traj.poses.append(pose)
        self.path_pub.publish(self.traj)
    
    def marker_cb(self, data):
        marker = Marker()
        marker.header.frame_id = 'map'
        marker.header.stamp = rospy.Time.now()
        marker.ns = 'points_and_lines'
        marker.id = 0
        marker.type = marker.POINTS
        marker.action = marker.ADD
        marker.pose = data.pose
        marker.pose.orientation.w = 1.0
        # marker.color.r = 0.0
        marker.color.g = 1.0
        # marker.color.b = 0.0
        marker.color.a = 1.0
        marker.scale.x = 0.2
        marker.scale.y = 0.2
        # marker.scale.z = 0.2
        marker.points = [Point(data.pose.position.x, data.pose.position.y, data.pose.position.z)]

        self.marker_array_pub.publish(marker)

    def takeoff(self, height=1.2):
        pose = Pose()
        pose.position.x = self.R_pose.position.x
        pose.position.y = self.R_pose.position.y
        pose.position.z = height
        pose.orientation.x = self.R_pose.orientation.x
        pose.orientation.y = self.R_pose.orientation.y
        pose.orientation.z = self.R_pose.orientation.z
        pose.orientation.w = self.R_pose.orientation.w
        pose_stamped = PoseStamped()
        pose_stamped.pose = pose


        while not self.is_terminal(self.R_pose.position.x,
                                   self.R_pose.position.y,
                                   height, 
                                   self.R_pose.orientation.x,
                                   self.R_pose.orientation.y,
                                   self.R_pose.orientation.z,
                                   self.R_pose.orientation.w):
            self.local_pos_pub.publish(pose_stamped)

        rospy.loginfo("Take Off! Height:{}".format(height))
        
    def is_terminal(self, x, y, z, q1, q2, q3, q4):
        pos_eps = .2
        ang_eps = 0.1
        R_eular = tf.transformations.euler_from_quaternion((self.R_pose.orientation.x, self.R_pose.orientation.y, self.R_pose.orientation.z, self.R_pose.orientation.w))
        eular = tf.transformations.euler_from_quaternion((q1, q2, q3, q4))
        return abs(x - self.R_pose.position.x) < pos_eps and \
            abs(y - self.R_pose.position.y) < pos_eps and \
            abs(z - self.R_pose.position.z) < pos_eps and \
            ( abs(R_eular[2] - eular[2]) < ang_eps or abs( abs(R_eular[2] - eular[2]) - 6.28 ) < ang_eps )

    def goto_xyz_Q(self, x, y, z, q1, q2, q3, q4, detect=False):
        if z == 0:
            self.results["ts"].append(datetime.now())
            self.results["log"].append("Point {:.3f}, {:.3f} {:.3f} is too low.".format(x, y, z))
            rospy.loginfo("Point {:.3f}, {:.3f} {:.3f} is too low.".format(x, y, z))
            return
        
        pose = Pose()
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z
        pose.orientation.x = q1
        pose.orientation.y = q2
        pose.orientation.z = q3
        pose.orientation.w = q4

        pose_stamped = PoseStamped()
        pose_stamped.pose = pose

        self.results["ts"].append(datetime.now())
        self.results["log"].append("Go to {:.3f}, {:.3f} {:.3f}, {:.3f}, {:.3f}, {:.3f}, {:.3f}".format(x, y, z, q1, q2, q3, q4))
        rospy.loginfo("Go to {:.3f}, {:.3f} {:.3f}, {:.3f}, {:.3f}, {:.3f}, {:.3f}".format(x, y, z, q1, q2, q3, q4))
        
        while not self.is_terminal(x, y, z, q1, q2, q3, q4):
            if(self.current_state.mode != "OFFBOARD" and (rospy.Time.now() - self.last_req) > rospy.Duration(5.0)):
                if(self.set_mode_client.call(self.offb_set_mode).mode_sent == True):
                    self.results["ts"].append(datetime.now())
                    self.results["log"].append("OFFBOARD enabled")
                    rospy.loginfo("OFFBOARD enabled")
                
                self.last_req = rospy.Time.now()
            else:
                if(not self.current_state.armed and (rospy.Time.now() - self.last_req) > rospy.Duration(5.0)):
                    if(self.arming_client.call(self.arm_cmd).success == True):
                        self.results["ts"].append(datetime.now())
                        self.results["log"].append("Vehicle armed")
                        rospy.loginfo("Vehicle armed")
                        
                        self.takeoff(1)
                
                    self.last_req = rospy.Time.now()
            
            self.local_pos_pub.publish(pose_stamped)
            self.rate.sleep()

            if time.time()-self.start_t > self.time_constraint:
                break
        
        # detect ar tag
        if detect:
            st = time.time()
            while (time.time()-st) < 2:
                if self.tag_id != "":
                    print(self.tag_id)
                    rospy.loginfo("ID {} found!".format(self.tag_id))
                    self.results["id_found"].append(self.tag_id)
                    self.results["id_found_ts"].append(datetime.now())
                    break

        if time.time()-self.start_t > self.time_constraint:
            return

    def goto_subgoals(self, way_points):
        self.last_req = rospy.Time.now()
        self.start_t = time.time()

        '''
        for (x, y, z, q1, q2, q3, q4) in way_points:
            if z == 0:
                self.results["ts"].append(datetime.now())
                self.results["log"].append("Point {:.3f}, {:.3f} {:.3f} is too low.".format(x, y, z))
                rospy.loginfo("Point {:.3f}, {:.3f} {:.3f} is too low.".format(x, y, z))
                continue
            pose = Pose()
            pose.position.x = x
            pose.position.y = y
            pose.position.z = z
            pose.orientation.x = q1
            pose.orientation.y = q2
            pose.orientation.z = q3
            pose.orientation.w = q4

            pose_stamped = PoseStamped()
            pose_stamped.pose = pose

            self.results["ts"].append(datetime.now())
            self.results["log"].append("Go to {:.3f}, {:.3f} {:.3f}, {:.3f}, {:.3f}, {:.3f}, {:.3f}".format(x, y, z, q1, q2, q3, q4))
            rospy.loginfo("Go to {:.3f}, {:.3f} {:.3f}, {:.3f}, {:.3f}, {:.3f}, {:.3f}".format(x, y, z, q1, q2, q3, q4))
            while not self.is_terminal(x, y, z, q1, q2, q3, q4):
                if(self.current_state.mode != "OFFBOARD" and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
                    if(self.set_mode_client.call(self.offb_set_mode).mode_sent == True):
                        self.results["ts"].append(datetime.now())
                        self.results["log"].append("OFFBOARD enabled")
                        rospy.loginfo("OFFBOARD enabled")
                    
                    last_req = rospy.Time.now()
                else:
                    if(not self.current_state.armed and (rospy.Time.now() - last_req) > rospy.Duration(5.0)):
                        if(self.arming_client.call(self.arm_cmd).success == True):
                            self.results["ts"].append(datetime.now())
                            self.results["log"].append("Vehicle armed")
                            rospy.loginfo("Vehicle armed")
                            
                            self.takeoff(1)
                    
                        last_req = rospy.Time.now()
                
                self.local_pos_pub.publish(pose_stamped)
                self.rate.sleep()

                if time.time()-start_t > 600:
                    break
            
            if time.time()-start_t > 600:
                break
            
            # detect ar tag
            st = time.time()
            while (time.time()-st) < 2:
                if self.tag_id != "":
                    print(self.tag_id)
                    rospy.loginfo("ID {} found!".format(self.tag_id))
                    self.results["id_found"].append(self.tag_id)
                    self.results["id_found_ts"].append(datetime.now())
                    break

        '''
        
        for (x, y, z, q1, q2, q3, q4) in way_points:
            theta = atan2( (y - self.R_pose.position.y), (x - self.R_pose.position.x) )
            q = tf.transformations.quaternion_from_euler(0.0, 0.0, theta)
            
            # Turn to terminal
            self.goto_xyz_Q(self.R_pose.position.x,
                            self.R_pose.position.y,
                            self.R_pose.position.z,
                            q[0],
                            q[1],
                            q[2],
                            q[3],
                            detect=False)
            
            # Go Forward
            self.goto_xyz_Q(x, y, z, q[0], q[1], q[2], q[3], detect=False)

            # Turn to yaw
            self.goto_xyz_Q(x, y, z, q1, q2, q3, q4, detect=True)

            if time.time()-self.start_t > self.time_constraint:
                rospy.loginfo("Time limit!")
                break

        
        self.results["ts"].append(datetime.now())
        self.results["log"].append("Landing...")
        rospy.loginfo("Landing...")
        self.offb_set_mode.custom_mode = 'AUTO.LAND'
        self.set_mode_client.call(self.offb_set_mode).mode_sent
        rospy.sleep(5)
        self.arm_cmd.value = False
        self.arming_client.call(self.arm_cmd)
        
        self.results["ts"].append(datetime.now())
        self.results["log"].append("Finished!")
        rospy.loginfo("Finished!")

    def save_results(self):
        with open(os.path.join(self.save_path, "uav_{}.pickle".format(self.uav_id)),
            'wb') as f:
            pickle.dump(self.results, f)
            print("Results saved!")
