#! /usr/bin/env python3
import pickle
import pickle
import os
import argparse

from UAV import UAV

if __name__ == "__main__":


    configs = {
        "ros_node": "offb_node_py_uav0",
        "state_sb": "/uav0/mavros/state",
        "pose_sb": "/uav0/mavros/local_position/pose",
        "local_pb": "/uav0/mavros/setpoint_position/local",
        "arm_srv": "/uav0/mavros/cmd/arming",
        "set_mode_srv": "/uav0/mavros/set_mode",
        "artag_sb": "/uav0/ar_tag",
        "odom":"/uav0/odom",
        "traj":"/uav0/traj",
        "artag":"/uav0/ar_tag",
        "camera":"/uav0/camera/color/image_raw",
        "marker":"/uav0/marker",
        "save_path": "./",
        "uav_id": 0,
    }
    # (x, y, z, q1, q2, q3, q4)
    way_points = [
        [0,1,2, 0, 0, 0, 1],
        [1,1,2, 0, 0, 0, 1],
        [1,0,2, 0, 0, 0, 1]
    ]

    uav = UAV(configs=configs)
    uav.goto_subgoals(way_points=way_points)

    uav.save_results()
